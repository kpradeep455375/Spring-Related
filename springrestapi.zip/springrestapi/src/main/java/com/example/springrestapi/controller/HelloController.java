package com.example.springrestapi.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
	
	@Value("${my.greeting}")
	private String greetingMessage;
	
	@Value("${demo.name}")
	private String demoNameVar;

	@RequestMapping("/hi/{name}")
	public String sayHi(@PathVariable String name) {
		return "Hi! " + name;
	}
	
	@RequestMapping("/greeting")
	public String greeting() {
		return greetingMessage;	
				
	}
	
	
	@GetMapping("/demoName")
	public String demoName() {
		return demoNameVar;
	}
}
